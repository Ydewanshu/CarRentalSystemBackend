package com.example.common;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.MockitoAnnotations;

/**
 * Common base test class to initialize Mockito mocks.
 * Extend this class in all service implementation test classes.
 */
public abstract class BaseServiceTest {

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
}
