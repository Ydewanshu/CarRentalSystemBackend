package com.example.registrationservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.example.common.BaseServiceTest;
import com.example.model.User;
import com.example.repository.UserRepository;
import com.example.service.UserServiceIMPL;

public class RegistrationServiceImplTest extends BaseServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserServiceIMPL registrationService;

    @Test
    void testRegisterUser_Success() {
        User user = new User("newuser@example.com", "password", "John", "Doe");

        when(userRepository.existsByEmail("newuser@example.com")).thenReturn(false);
        when(userRepository.save(user)).thenReturn(user);

        boolean result = registrationService.register(user);

        assertTrue(result);
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void testRegisterUser_EmailAlreadyExists() {
        User user = new User("existing@example.com", "password", "Jane", "Smith");

        when(userRepository.existsByEmail("existing@example.com")).thenReturn(true);

        boolean result = registrationService.register(user);

        assertFalse(result);
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void testGetAllUsers() {
        List<User> users = Arrays.asList(
            new User("user1@example.com", "pass", "A", "B"),
            new User("user2@example.com", "word", "X", "Y")
        );

        when(userRepository.findAll()).thenReturn(users);

        List<User> result = registrationService.getAllUsers();

        assertEquals(2, result.size());
        assertEquals("user1@example.com", result.get(0).getEmail());
        assertEquals("user2@example.com", result.get(1).getEmail());
    }

    @Test
    void testFindByEmail_UserExists() {
        User user = new User("user@example.com", "123", "Foo", "Bar");
        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(user));

        Optional<User> result = registrationService.findByEmail("user@example.com");

        assertTrue(result.isPresent());
        assertEquals("user@example.com", result.get().getEmail());
    }

    @Test
    void testFindByEmail_UserDoesNotExist() {
        when(userRepository.findByEmail("absent@example.com")).thenReturn(Optional.empty());

        Optional<User> result = registrationService.findByEmail("absent@example.com");

        assertFalse(result.isPresent());
    }
}
