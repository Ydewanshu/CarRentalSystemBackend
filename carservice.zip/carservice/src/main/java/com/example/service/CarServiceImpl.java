package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.model.Car;
import com.example.repository.CarRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CarServiceImpl implements CarService {
	
	public CarServiceImpl(CarRepository carRepository) {
        this.carRepository = carRepository;
    }
    private final CarRepository carRepository;

    @Override
    public Car addCar(Car car) {
        return carRepository.save(car);
    }

    @Override
    public List<Car> getAllCars() {
        return carRepository.findAll();
    }
}