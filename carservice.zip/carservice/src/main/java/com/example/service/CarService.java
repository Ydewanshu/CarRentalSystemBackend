package com.example.service;

import java.util.List;

import com.example.model.Car;

public interface CarService {
    Car addCar(Car car);
    List<Car> getAllCars();
}