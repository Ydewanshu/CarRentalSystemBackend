package com.example.common;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.MockitoAnnotations;

/**
 * Base test class that initializes mocks.
 */
public abstract class BaseServiceTest {

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }
}
