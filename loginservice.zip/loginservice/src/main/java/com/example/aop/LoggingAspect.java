package com.example.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    @Before("execution(* com.example.service..*(..))")
    public void logBefore(JoinPoint joinPoint) {
        logger.info("Started: " + joinPoint.getSignature());
    }

    @AfterReturning(pointcut = "execution(* com.capgemini.loginservice.service..*(..))", returning = "result")
    public void logAfter(JoinPoint joinPoint, Object result) {
        logger.info("Ended: " + joinPoint.getSignature() + " | Returned: " + result);
    }

    @AfterThrowing(pointcut = "execution(* com.capgemini.loginservice.service..*(..))", throwing = "ex")
    public void logError(JoinPoint joinPoint, Throwable ex) {
        logger.error("Exception in " + joinPoint.getSignature() + ": " + ex.getMessage());
    }
}
