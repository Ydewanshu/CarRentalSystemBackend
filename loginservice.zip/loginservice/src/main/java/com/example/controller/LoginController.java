package com.example.controller;

import com.example.model.JwtResponse;
import com.example.model.LoginRequest;
import com.example.model.User;
import com.example.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/login")
@RequiredArgsConstructor
public class LoginController {
	public LoginController(AuthService authService) {
	    this.authService = authService;
	}

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        String result = authService.register(user);
        if (result.equals("Email already exists!")) {
            return ResponseEntity.status(400).body(result);
        }
        return ResponseEntity.ok(result);
    }

    @PostMapping
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        String jwtToken = authService.login(loginRequest.getEmail(), loginRequest.getPassword());
        if (jwtToken.equals("Invalid credentials")) {
            return ResponseEntity.status(401).body("Unauthorized: Invalid email or password");
        } else {
            return ResponseEntity.ok(new JwtResponse(jwtToken));
        }
    }
}
