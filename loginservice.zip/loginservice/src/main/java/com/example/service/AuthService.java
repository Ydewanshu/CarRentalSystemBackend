package com.example.service;

import com.example.model.User;

public interface AuthService {
    String login(String email, String password);
    String register(User user);
}
