package com.example.common;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.MockitoAnnotations;

/**
 * Common base class for all unit tests.
 * Initializes Mockito annotations.
 */
public abstract class BaseServiceTest {

    @BeforeEach
    public void initMocks() {
        MockitoAnnotations.openMocks(this);  // Initializes @Mock, @InjectMocks, etc.
    }
}
